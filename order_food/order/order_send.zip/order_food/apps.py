from django.apps import AppConfig


class OrderfoodConfig(AppConfig):
    name = 'order_food'
