from django.contrib import admin

from order_food.models import Food

admin.site.register(Food)
